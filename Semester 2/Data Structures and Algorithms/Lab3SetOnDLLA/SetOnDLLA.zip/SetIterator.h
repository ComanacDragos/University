#pragma once
#include "Set.h"
#include <exception>

class SetIterator
{
	//DO NOT CHANGE THIS PART
	friend class Set;
private:
	//DO NOT CHANGE THIS PART
	const Set& set;
	SetIterator(const Set& s);

	//TODO - Representation
	int current, previous=-1;

public:
	void first();
	void next();
	TElem getCurrent();
	bool valid() const;

	void prev()
	{
		if (this->current == this->set.head && this->previous == -1)
			throw std::exception("bla");
		this->current = this->previous;
		this->previous = this->set.nodes[this->current].prev;
	
	}
};


