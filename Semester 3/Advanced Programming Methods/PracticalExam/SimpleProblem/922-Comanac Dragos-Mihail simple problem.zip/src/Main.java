/*import View.ConsoleUserInterface.View;
import View.GUI.GUIView;

public class Main{
    public static void main(String[] args) {
        //new View().start();
        new GUIView(args);
    }
}*/

