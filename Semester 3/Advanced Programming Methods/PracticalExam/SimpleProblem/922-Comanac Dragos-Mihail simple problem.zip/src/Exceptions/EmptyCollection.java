package Exceptions;

public class EmptyCollection extends MyException{
    public EmptyCollection(){}

    public EmptyCollection(String message){
        super(message);
    }


}
