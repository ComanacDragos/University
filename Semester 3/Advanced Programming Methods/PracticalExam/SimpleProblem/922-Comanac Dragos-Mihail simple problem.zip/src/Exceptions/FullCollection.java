package Exceptions;

public class FullCollection extends MyException{
    public FullCollection(){}

    public FullCollection(String message){
        super(message);
    }
}
