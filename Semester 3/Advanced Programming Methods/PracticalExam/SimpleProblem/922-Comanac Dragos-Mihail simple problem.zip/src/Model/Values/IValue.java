package Model.Values;

import Model.Types.IType;

public interface IValue {
    IType getType();

    IValue deepCopy();

    String toString();
}
