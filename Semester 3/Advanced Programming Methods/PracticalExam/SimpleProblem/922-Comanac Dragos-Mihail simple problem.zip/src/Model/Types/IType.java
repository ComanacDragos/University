package Model.Types;

import Model.Values.IValue;

public interface IType {
    IValue getDefaultValue();
}
