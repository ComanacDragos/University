package Exceptions;

public class EmptyExecutionStack extends EmptyCollection{
    EmptyExecutionStack(){
        super("Empty execution stack");
    }
}
