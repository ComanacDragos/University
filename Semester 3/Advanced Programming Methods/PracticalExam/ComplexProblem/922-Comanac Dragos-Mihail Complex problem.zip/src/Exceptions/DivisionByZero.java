package Exceptions;

public class DivisionByZero extends MyException{
    public DivisionByZero(){
        super("Division by zero");
    }
}
