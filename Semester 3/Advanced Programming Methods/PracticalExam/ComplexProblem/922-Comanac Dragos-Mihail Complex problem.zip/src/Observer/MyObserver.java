package Observer;

public abstract class MyObserver {
    abstract public void update();
}
