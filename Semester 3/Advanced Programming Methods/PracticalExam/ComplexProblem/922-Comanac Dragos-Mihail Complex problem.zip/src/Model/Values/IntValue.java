package Model.Values;

import Model.Types.IType;
import Model.Types.IntType;

public class IntValue implements IValue{
    int value;

    public IntValue(){
        this.value = (new IntType()).getDefaultValue().getValue();
    }

    public IntValue(int value){
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    @Override
    public IType getType() {
        return new IntType();
    }

    @Override
    public IntValue deepCopy() {
        return new IntValue(this.value);
    }

    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof IntValue))
            return false;
        return this.value == ((IntValue) obj).getValue();
    }

    @Override
    public String toString() {
        return String.valueOf(this.value);
    }
}
