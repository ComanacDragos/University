package catalog.repository;

import org.junit.Ignore;
import org.junit.Test;
import ro.ubb.catalog.domain.validators.ValidatorException;

import static org.junit.Assert.fail;

/**
 * @author radu.
 */
public class InMemoryRepositoryTest {

    @Ignore
    @Test
    public void testFindOne() throws Exception {
        fail("Not yet tested");
    }

    @Ignore
    @Test
    public void testFindAll() throws Exception {
        fail("Not yet tested");
    }

    @Ignore
    @Test
    public void testSave() throws Exception {
        fail("Not yet tested");
    }

    @Ignore
    @Test(expected = ValidatorException.class)
    public void testSaveException() throws Exception {
        fail("Not yet tested");
    }

    @Ignore
    @Test
    public void testDelete() throws Exception {
        fail("Not yet tested");
    }

    @Ignore
    @Test
    public void testUpdate() throws Exception {
        fail("Not yet tested");
    }

    @Ignore
    @Test(expected = ValidatorException.class)
    public void testUpdateException() throws Exception {
        fail("Not yet tested");
    }
}