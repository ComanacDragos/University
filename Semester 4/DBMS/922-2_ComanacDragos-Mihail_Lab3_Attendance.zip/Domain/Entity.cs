﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Libraries.Domain
{
    public class Entity<ID>
    {
        public ID Id { get; set; }
    }
}
