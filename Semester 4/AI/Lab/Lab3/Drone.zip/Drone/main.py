from Drone.UI.GUI import *

if __name__ == '__main__':
    GUI()

    #service = Service()
    #service.setLog(True)
    #for i in range(40):
     #   print(f"Start {i}")
    #    service.solver()
    #print(service.computeStats('fitness'))

    #print(service.computeStats('detectedPositions'))