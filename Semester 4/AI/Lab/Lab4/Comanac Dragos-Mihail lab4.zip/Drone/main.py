from UI.GUI import *

if __name__ == '__main__':
    GUI()

