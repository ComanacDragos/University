from UI.UI import *

if __name__ == '__main__':
    UI().run()
