from torch import sin
from math import pi
import torch


def sinFunction(x1, x2):
    return sin(x1 + x2/pi)
